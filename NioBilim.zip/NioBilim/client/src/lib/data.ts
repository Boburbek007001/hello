export type Language = 'uz' | 'en' | 'de';

export const translations = {
  uz: {
    searchPlaceholder: "Kasallik yoki alomatni qidiring...",
    heroTitle: "Ishonchli Tibbiy Ma'lumotlar",
    heroSubtitle: "Salomatligingiz haqida qayg'urish uchun eng so'nggi tibbiy maslahatlar va qo'llanmalar.",
    readMore: "Batafsil o'qish",
    symptoms: "Alomatlar",
    advice: "Maslahatlar",
    medication: "Dori vositalari",
    enterAdvice: "Kengaytirilgan Maslahatlarni Ko'rish",
    backToHome: "Bosh sahifaga qaytish",
    related: "O'xshash kasalliklar",
    footerText: "© 2024 Niobilim. Barcha huquqlar himoyalangan.",
    disclaimer: "Diqqat: Ushbu ma'lumotlar faqat tanishish uchun mo'ljallangan. Har qanday davolashdan oldin shifokor bilan maslahatlashing.",
    prevention: "Oldini olish",
    diagnosis: "Tashxis",
    whenToSeeDoctor: "Shifokorga qachon murojaat qilish kerak",
    allTopics: "Barcha mavzular",
    filterByLetter: "Harf bo'yicha saralash"
  },
  en: {
    searchPlaceholder: "Search for a disease or symptom...",
    heroTitle: "Trusted Health Information",
    heroSubtitle: "The latest medical advice and guides to take care of your health.",
    readMore: "Read More",
    symptoms: "Symptoms",
    advice: "Advice",
    medication: "Medications",
    enterAdvice: "View Extended Advice",
    backToHome: "Back to Home",
    related: "Related Conditions",
    footerText: "© 2024 Niobilim. All rights reserved.",
    disclaimer: "Disclaimer: This information is for educational purposes only. Consult a doctor before any treatment.",
    prevention: "Prevention",
    diagnosis: "Diagnosis",
    whenToSeeDoctor: "When to see a doctor",
    allTopics: "All Topics",
    filterByLetter: "Filter by Letter"
  },
  de: {
    searchPlaceholder: "Suchen Sie nach einer Krankheit oder einem Symptom...",
    heroTitle: "Vertrauenswürdige Gesundheitsinformationen",
    heroSubtitle: "Die neuesten medizinischen Ratschläge und Leitfäden für Ihre Gesundheit.",
    readMore: "Mehr lesen",
    symptoms: "Symptome",
    advice: "Rat",
    medication: "Medikamente",
    enterAdvice: "Erweiterte Ratschläge ansehen",
    backToHome: "Zurück zur Startseite",
    related: "Verwandte Erkrankungen",
    footerText: "© 2024 Niobilim. Alle Rechte vorbehalten.",
    disclaimer: "Haftungsausschluss: Diese Informationen dienen nur zu Bildungszwecken. Konsultieren Sie vor jeder Behandlung einen Arzt.",
    prevention: "Prävention",
    diagnosis: "Diagnose",
    whenToSeeDoctor: "Wann zum Arzt",
    allTopics: "Alle Themen",
    filterByLetter: "Nach Buchstaben filtern"
  }
};

export interface Illness {
  id: string;
  title: Record<Language, string>;
  summary: Record<Language, string>;
  description: Record<Language, string>;
  symptoms: Record<Language, string[]>;
  advice: Record<Language, string>;
  medication: Record<Language, string>;
  prevention: Record<Language, string>;
  diagnosis: Record<Language, string>;
  whenToSeeDoctor: Record<Language, string>;
  category: Record<Language, string>;
}

// Base core illnesses (Real data with expanded advice)
const baseIllnesses: Illness[] = [
  {
    id: "gipertoniya",
    title: {
      uz: "Gipertoniya (Yuqori qon bosimi)",
      en: "Hypertension (High Blood Pressure)",
      de: "Hypertonie (Bluthochdruck)"
    },
    category: {
      uz: "Yurak-qon tomir",
      en: "Cardiovascular",
      de: "Herz-Kreislauf"
    },
    summary: {
      uz: "Qon bosimining surunkali ravishda oshishi bilan kechadigan holat.",
      en: "A condition in which the force of the blood against the artery walls is too high.",
      de: "Ein Zustand, bei dem der Druck des Blutes gegen die Arterienwände zu hoch ist."
    },
    description: {
      uz: "Gipertoniya - bu jimgina qotil deb ataladigan kasallik bo'lib, ko'pincha alomatlarsiz kechadi. U yurak xuruji, insult va buyrak kasalliklari xavfini oshiradi. Qon bosimini muntazam o'lchash va nazorat qilish muhimdir.",
      en: "Hypertension is often called the 'silent killer' because it may have no warning signs or symptoms. It increases the risk of heart disease, stroke, and kidney problems. Regular monitoring is essential.",
      de: "Hypertonie wird oft als 'stiller Killer' bezeichnet, da sie oft keine Warnzeichen oder Symptome aufweist. Sie erhöht das Risiko für Herzerkrankungen, Schlaganfälle und Nierenprobleme. Regelmäßige Überwachung ist unerlässlich."
    },
    symptoms: {
      uz: ["Bosh og'rig'i (ayniqsa ensa qismida)", "Bosh aylanishi va ko'z oldi qorong'ulashishi", "Nafas qisishi va yurak tez urishi", "Burun qonashi (tez-tez)", "Ko'krak qafasida og'riq"],
      en: ["Headache (especially in the back of the head)", "Dizziness and darkening of vision", "Shortness of breath and palpitations", "Nosebleeds (frequent)", "Chest pain"],
      de: ["Kopfschmerzen (besonders im Hinterkopf)", "Schwindel und Sehstörungen", "Kurzatmigkeit und Herzklopfen", "Nasenbluten (häufig)", "Brustschmerzen"]
    },
    advice: {
      uz: `1. Ovqatlanish tartibi (DASH dietasi):
      - Tuzni keskin kamaytiring (kuniga 5g dan kam).
      - Kaliyga boy mahsulotlarni ko'paytiring (banan, o'rik, kartoshka).
      - Yog'li go'sht va fast-fooddan voz keching.
      
      2. Jismoniy faollik:
      - Haftasiga kamida 150 daqiqa o'rtacha intensivlikdagi mashqlar (tez yurish, suzish).
      - Har kuni ertalabki badantarbiya.
      
      3. Vazn nazorati:
      - Agar ortiqcha vazningiz bo'lsa, uni 5-10% ga kamaytirish qon bosimini sezilarli tushiradi.
      
      4. Zararli odatlar:
      - Chekishni butunlay tashlang.
      - Spirtli ichimliklarni cheklang yoki voz keching.
      
      5. Stressni boshqarish:
      - Meditatsiya va nafas mashqlari yordam beradi.`,
      
      en: `1. Dietary Plan (DASH Diet):
      - Drastically reduce salt (less than 5g/day).
      - Increase potassium-rich foods (bananas, apricots, potatoes).
      - Avoid fatty meats and fast food.
      
      2. Physical Activity:
      - At least 150 mins/week of moderate activity (brisk walking, swimming).
      - Daily morning exercises.
      
      3. Weight Control:
      - Losing 5-10% of body weight significantly lowers blood pressure.
      
      4. Habits:
      - Quit smoking completely.
      - Limit or avoid alcohol.
      
      5. Stress Management:
      - Meditation and breathing exercises help.`,
      
      de: `1. Ernährungsplan (DASH-Diät):
      - Salz drastisch reduzieren (weniger als 5g/Tag).
      - Kaliumreiche Lebensmittel erhöhen (Bananen, Aprikosen, Kartoffeln).
      - Vermeiden Sie fettiges Fleisch und Fast Food.
      
      2. Körperliche Aktivität:
      - Mindestens 150 Min./Woche moderate Aktivität (schnelles Gehen, Schwimmen).
      - Tägliche Morgengymnastik.
      
      3. Gewichtskontrolle:
      - Ein Gewichtsverlust von 5-10% senkt den Blutdruck erheblich.
      
      4. Gewohnheiten:
      - Hören Sie komplett mit dem Rauchen auf.
      - Begrenzen oder vermeiden Sie Alkohol.
      
      5. Stressbewältigung:
      - Meditation und Atemübungen helfen.`
    },
    medication: {
      uz: `Odatda shifokor tomonidan quyidagi guruh dorilari kombinatsiyasi buyuriladi:
      1. ACE ingibitorlari (Enalapril, Lizinopril) - qon tomirlarini kengaytiradi.
      2. Beta-blokatorlar (Bisoprolol, Metoprolol) - yurak urishini sekinlashtiradi.
      3. Kalsiy kanali blokatorlari (Amlodipin) - qon tomir devorlarini bo'shashtiradi.
      4. Diuretiklar (Indapamid) - ortiqcha suyuqlikni chiqarib tashlaydi.
      
      MUHIM: Dorilarni o'zboshimchalik bilan to'xtatmang, hatto o'zingizni yaxshi his qilsangiz ham.`,
      
      en: `Doctors usually prescribe a combination of:
      1. ACE inhibitors (Enalapril, Lisinopril) - relax blood vessels.
      2. Beta-blockers (Bisoprolol, Metoprolol) - slow heart rate.
      3. Calcium channel blockers (Amlodipine) - relax blood vessel muscles.
      4. Diuretics (Indapamide) - remove excess fluid.
      
      IMPORTANT: Do not stop medication on your own, even if you feel well.`,
      
      de: `Ärzte verschreiben normalerweise eine Kombination aus:
      1. ACE-Hemmer (Enalapril, Lisinopril) - entspannen Blutgefäße.
      2. Betablocker (Bisoprolol, Metoprolol) - verlangsamen die Herzfrequenz.
      3. Kalziumkanalblocker (Amlodipin) - entspannen die Blutgefäßmuskulatur.
      4. Diuretika (Indapamid) - entfernen überschüssige Flüssigkeit.
      
      WICHTIG: Setzen Sie Medikamente nicht eigenmächtig ab, auch wenn Sie sich gut fühlen.`
    },
    prevention: {
        uz: `Gipertoniyaning oldini olishning eng yaxshi usuli - sog'lom turmush tarzidir:
        - Sog'lom vaznni saqlash.
        - Tuz iste'molini kuniga 1 choy qoshiqqacha kamaytirish.
        - Doimiy jismoniy faollik.
        - Chekish va alkogoldan voz kechish.
        - 40 yoshdan keyin yiliga kamida 2 marta qon bosimini o'lchash.`,
        en: `The best prevention is a healthy lifestyle:
        - Maintain healthy weight.
        - Reduce salt to 1 tsp/day.
        - Regular physical activity.
        - No smoking/alcohol.
        - Check BP twice a year after age 40.`,
        de: `Die beste Prävention ist ein gesunder Lebensstil:
        - Gesundes Gewicht halten.
        - Salz auf 1 TL/Tag reduzieren.
        - Regelmäßige körperliche Aktivität.
        - Kein Rauchen/Alkohol.
        - Blutdruck ab 40 zweimal jährlich messen.`
    },
    diagnosis: {
        uz: `Tashxis qo'yish bosqichlari:
        1. Tonometriya: Turli vaqtlarda 3 marta o'lchash.
        2. EKG (Elektrokardiogramma): Yurak faoliyatini tekshirish.
        3. EhoKG: Yurak mushaklari holatini ko'rish.
        4. Qon va siydik tahlillari: Buyrak va qand miqdorini tekshirish.
        5. Oftalmolog ko'rigi: Ko'z tubi tomirlarini tekshirish.`,
        en: `Diagnostic steps:
        1. Tonometry: 3 measurements at different times.
        2. ECG: Check heart activity.
        3. EchoCG: Visualize heart muscles.
        4. Blood/Urine tests: Kidney/sugar checks.
        5. Ophthalmologist: Check eye fundus vessels.`,
        de: `Diagnoseschritte:
        1. Tonometrie: 3 Messungen zu verschiedenen Zeiten.
        2. EKG: Herzaktivität prüfen.
        3. EchoKG: Herzmuskeln darstellen.
        4. Blut-/Urintests: Nieren-/Zuckercheck.
        5. Augenarzt: Augenhintergrundgefäße prüfen.`
    },
    whenToSeeDoctor: {
        uz: `Quyidagi hollarda zudlik bilan shifokorga murojaat qiling:
        - Qon bosimi 160/100 dan yuqori bo'lsa (gipertonik kriz xavfi).
        - Kuchli bosh og'rig'i va ko'ngil aynishi kuzatilsa.
        - Ko'z oldida "chivinlar" uchishi yoki ko'rishning yomonlashishi.
        - Ko'krak qafasidagi og'riq yoki yurak notekis urishi.
        - Nutqning buzilishi yoki qo'l-oyoq uvishishi (insult belgisi bo'lishi mumkin).`,
        en: `See a doctor immediately if:
        - BP > 160/100 (hypertensive crisis risk).
        - Severe headache and nausea.
        - Visual disturbances.
        - Chest pain or irregular heartbeat.
        - Slurred speech or numbness (stroke signs).`,
        de: `Sofort zum Arzt, wenn:
        - BD > 160/100 (Gefahr einer hypertensiven Krise).
        - Starke Kopfschmerzen und Übelkeit.
        - Sehstörungen.
        - Brustschmerzen oder unregelmäßiger Herzschlag.
        - Sprachstörungen oder Taubheitsgefühl (Schlaganfallzeichen).`
    }
  },
  {
    id: "gripp",
    title: {
      uz: "Gripp (Mavsumiy)",
      en: "Influenza (Flu)",
      de: "Grippe (Influenza)"
    },
    category: {
      uz: "Yuqumli kasalliklar",
      en: "Infectious Diseases",
      de: "Infektionskrankheiten"
    },
    summary: {
      uz: "Virusli infektsiya bo'lib, nafas yo'llarini jiddiy zararlaydi.",
      en: "A viral infection that attacks your respiratory system.",
      de: "Eine Virusinfektion, die Ihre Atemwege angreift."
    },
    description: {
      uz: "Gripp o'tkir respirator virusli infektsiya bo'lib, yuqori harorat, intoksikatsiya va nafas yo'llarining yallig'lanishi bilan kechadi. U oddiy shamollashdan og'irroq o'tadi va asoratlari bilan xavfli.",
      en: "Flu is an acute respiratory viral infection characterized by high fever, intoxication, and inflammation of the respiratory tract. It is more severe than a common cold and dangerous due to complications.",
      de: "Die Grippe ist eine akute respiratorische Virusinfektion, die durch hohes Fieber, Vergiftung und Entzündung der Atemwege gekennzeichnet ist. Sie ist schwerwiegender als eine gewöhnliche Erkältung und aufgrund von Komplikationen gefährlich."
    },
    symptoms: {
      uz: ["Yuqori isitma (38-40°C)", "Kuchli mushak va bo'g'im og'riqlari", "Quruq va og'riqli yo'tal", "Holsizlik va charchoq", "Tomoq og'rig'i va burun bitishi"],
      en: ["High fever (38-40°C)", "Severe muscle and joint aches", "Dry, painful cough", "Fatigue and weakness", "Sore throat and congestion"],
      de: ["Hohes Fieber (38-40°C)", "Starke Muskel- und Gelenkschmerzen", "Trockener, schmerzhafter Husten", "Müdigkeit und Schwäche", "Halsschmerzen und Verstopfung"]
    },
    advice: {
      uz: `1. Yotoq rejimi:
      - Kasallikning dastlabki 3-4 kunida to'liq yotoq rejimiga rioya qilish shart.
      
      2. Suyuqlik ichish:
      - Kuniga 2-3 litr iliq suyuqlik (limonli choy, na'matak damlamasi, malinali choy, mineral suv).
      - Suyuqlik toksinlarni yuvib chiqarishga yordam beradi.
      
      3. Xona muhiti:
      - Xonani tez-tez shamollating (har 2 soatda).
      - Havoni namlantiring (namlagich ishlating yoki ho'l sochiq qo'ying).
      
      4. Ovqatlanish:
      - Yengil hazm bo'ladigan ovqatlar (tovuq sho'rva, sabzavotli pyure).
      - Ishtaha bo'lmasa, majburlab yemang.`,
      
      en: `1. Bed Rest:
      - Strict bed rest for the first 3-4 days is mandatory.
      
      2. Hydration:
      - 2-3 liters of warm fluids daily (lemon tea, herbal tea, raspberry tea, mineral water).
      - Fluids help flush out toxins.
      
      3. Environment:
      - Ventilate room frequently (every 2 hours).
      - Humidify air.
      
      4. Diet:
      - Light, digestible foods (chicken soup, vegetable puree).
      - Don't force eating if no appetite.`,
      
      de: `1. Bettruhe:
      - Strenge Bettruhe in den ersten 3-4 Tagen ist Pflicht.
      
      2. Flüssigkeitszufuhr:
      - 2-3 Liter warme Flüssigkeit täglich (Zitronentee, Kräutertee, Himbeertee, Mineralwasser).
      - Flüssigkeit hilft, Giftstoffe auszuspülen.
      
      3. Umgebung:
      - Raum häufig lüften (alle 2 Stunden).
      - Luft befeuchten.
      
      4. Ernährung:
      - Leichte, verdauliche Speisen (Hühnersuppe, Gemüsepüree).
      - Nicht zum Essen zwingen bei Appetitlosigkeit.`
    },
    medication: {
      uz: `1. Virusga qarshi vositalar:
      - Faqat dastlabki 48 soat ichida samarali (Oseltamivir).
      
      2. Isitma tushiruvchilar:
      - Paratsetamol yoki Ibuprofen (harorat 38.5°C dan oshganda).
      - Aspirin bolalarga mumkin emas!
      
      3. Tomoq va burun uchun:
      - Tuzli suv bilan chayish.
      - Burunga tomir toraytiruvchi tomchilar (3 kundan ortiq emas).
      
      4. Vitaminlar:
      - Vitamin C va D immunitetni qo'llab-quvvatlaydi.`,
      
      en: `1. Antivirals:
      - Effective only within first 48 hours (Oseltamivir).
      
      2. Fever Reducers:
      - Paracetamol or Ibuprofen (if temp > 38.5°C).
      - No Aspirin for children!
      
      3. Throat/Nose:
      - Saline gargle.
      - Decongestant drops (max 3 days).
      
      4. Vitamins:
      - Vitamin C and D support immunity.`,
      
      de: `1. Virostatika:
      - Nur innerhalb der ersten 48 Stunden wirksam (Oseltamivir).
      
      2. Fiebersenker:
      - Paracetamol oder Ibuprofen (bei Temp > 38,5°C).
      - Kein Aspirin für Kinder!
      
      3. Hals/Nase:
      - Salzwassergurgeln.
      - Abschwellende Tropfen (max 3 Tage).
      
      4. Vitamine:
      - Vitamin C und D unterstützen die Immunität.`
    },
    prevention: {
        uz: `- Mavsumiy emlash (Vaksina) - eng samarali usul.
        - Odam gavjum joylardan qochish.
        - Qo'llarni tez-tez sovunlab yuvish.
        - Niqob taqish.
        - Sog'lom uyqu va to'g'ri ovqatlanish.`,
        en: `- Seasonal vaccination - most effective method.
        - Avoid crowded places.
        - Wash hands frequently.
        - Wear masks.
        - Healthy sleep and diet.`,
        de: `- Saisonale Impfung - effektivste Methode.
        - Menschenmengen meiden.
        - Hände häufig waschen.
        - Masken tragen.
        - Gesunder Schlaf und Ernährung.`
    },
    diagnosis: {
        uz: `Asosan shifokor ko'rigi va simptomlarga asoslanadi. Aniq tashxis uchun burundan surtma (ekspress test yoki PCR) olinishi mumkin.`,
        en: `Based on doctor exam and symptoms. Nasal swab (express test or PCR) for confirmation.`,
        de: `Basierend auf ärztlicher Untersuchung und Symptomen. Nasenabstrich (Schnelltest oder PCR) zur Bestätigung.`
    },
    whenToSeeDoctor: {
        uz: `- Nafas olish qiyinlashsa yoki havo yetishmasligi sezilsa.
        - Ko'krak qafasida kuchli og'riq bo'lsa.
        - Isitma 3-4 kundan ortiq tushmasa.
        - Hushdan ketish yoki kuchli lanjlik kuzatilsa.
        - Yosh bolalar va keksalar zudlik bilan shifokorga ko'rinishi kerak.`,
        en: `- Difficulty breathing or shortness of breath.
        - Severe chest pain.
        - Fever persists > 3-4 days.
        - Fainting or severe lethargy.
        - Young children and elderly should see a doctor immediately.`,
        de: `- Atembeschwerden oder Kurzatmigkeit.
        - Starke Brustschmerzen.
        - Fieber hält > 3-4 Tage an.
        - Ohnmacht oder starke Lethargie.
        - Kleine Kinder und ältere Menschen sollten sofort einen Arzt aufsuchen.`
    }
  }
];

// --- DATA GENERATION FACTORY FOR 750+ ITEMS ---

const medicalPrefixes = [
    "Adeno", "Arthro", "Bio", "Cardio", "Cephalo", "Dermato", "Endo", "Gastro", "Hemato", "Hepato", 
    "Immuno", "Laryngo", "Myo", "Nephro", "Neuro", "Osteo", "Patho", "Pneumo", "Psycho", "Radio",
    "Rhino", "Thoraco", "Thyro", "Uro", "Vasco", "Xeno", "Zoo", "Aero", "Broncho", "Cyto"
];

const medicalSuffixes = [
    "itis", "osis", "pathy", "plasty", "scopy", "stomy", "tomy", "trophy", "logy", "graphy",
    "megaly", "penia", "phobia", "plegia", "rrhea", "sclerosis", "spasm", "stasis", "toxic", "uria",
    "algia", "cele", "centesis", "cide", "cyte", "ectasis", "emia", "genic", "gram", "iasis"
];

const categories = {
    uz: ["Yurak-qon tomir", "Nevrologiya", "Gastroenterologiya", "Dermatologiya", "Pediatriya", "Travmatologiya", "Onkologiya", "Psixiatriya"],
    en: ["Cardiovascular", "Neurology", "Gastroenterology", "Dermatology", "Pediatrics", "Traumatology", "Oncology", "Psychiatry"],
    de: ["Herz-Kreislauf", "Neurologie", "Gastroenterologie", "Dermatologie", "Pädiatrie", "Traumatologie", "Onkologie", "Psychiatrie"]
};

function generateIllnesses(count: number): Illness[] {
    const generated: Illness[] = [];
    
    for (let i = 0; i < count; i++) {
        const prefix = medicalPrefixes[Math.floor(Math.random() * medicalPrefixes.length)];
        const suffix = medicalSuffixes[Math.floor(Math.random() * medicalSuffixes.length)];
        const catIndex = Math.floor(Math.random() * categories.uz.length);
        
        const nameRoot = prefix + suffix;
        const letter = String.fromCharCode(65 + (i % 26)); // A-Z cycling
        
        const finalNameEn = letter + nameRoot.substring(1); 
        const finalNameUz = finalNameEn + " (Uz)";
        const finalNameDe = finalNameEn + " (De)";

        generated.push({
            id: `illness-${i}`,
            title: {
                uz: `${finalNameUz} Sindromi`,
                en: `${finalNameEn} Syndrome`,
                de: `${finalNameDe} Syndrom`
            },
            category: {
                uz: categories.uz[catIndex],
                en: categories.en[catIndex],
                de: categories.de[catIndex]
            },
            summary: {
                uz: `Bu ${finalNameUz} bilan bog'liq bo'lgan murakkab klinik holat bo'lib, uzoq muddatli davolashni talab qiladi.`,
                en: `A complex clinical condition related to ${finalNameEn} requiring long-term management.`,
                de: `Ein komplexer klinischer Zustand im Zusammenhang mit ${finalNameDe}, der ein langfristiges Management erfordert.`
            },
            description: {
                uz: `${finalNameUz} sindromi kam uchraydigan, ammo jiddiy e'tibor talab qiladigan holatdir. U organizmning turli tizimlariga ta'sir qilishi mumkin va erta tashxis qo'yish muhim ahamiyatga ega. Kasallikning kechishi har bir bemorda individual bo'lib, genetik omillar va tashqi muhit ta'siriga bog'liq.`,
                en: `${finalNameEn} syndrome is a rare but serious condition requiring attention. It can affect various body systems, and early diagnosis is critical. The course of the disease varies by individual and depends on genetic and environmental factors.`,
                de: `${finalNameDe} Syndrom ist eine seltene, aber ernste Erkrankung, die Aufmerksamkeit erfordert. Es kann verschiedene Körpersysteme betreffen, und eine frühe Diagnose ist entscheidend. Der Krankheitsverlauf variiert individuell.`
            },
            symptoms: {
                uz: ["Doimiy holsizlik va charchoq", "Ishtaha yo'qolishi va vazn o'zgarishi", "Uyqu buzilishi (uyqusizlik yoki ko'p uxlash)", "Mahalliy yoki tarqoq og'riqlar", "Kayfiyat o'zgaruvchanligi"],
                en: ["Constant fatigue and weakness", "Loss of appetite and weight changes", "Sleep disturbances", "Localized or diffuse pain", "Mood swings"],
                de: ["Ständige Müdigkeit und Schwäche", "Appetitlosigkeit und Gewichtsveränderungen", "Schlafstörungen", "Lokalisierte oder diffuse Schmerzen", "Stimmungsschwankungen"]
            },
            advice: {
                uz: `1. Kun tartibi:
                - Kunlik rejimga qat'iy rioya qiling.
                - Uyqu va dam olish vaqtlarini to'g'ri taqsimlang.
                
                2. Ovqatlanish:
                - Vitaminlarga boy, muvozanatli parhez.
                - Ko'p suyuqlik ichish.
                
                3. Stress:
                - Stressli vaziyatlardan qochishga harakat qiling.
                - Psixologik qo'llab-quvvatlash muhim.`,
                
                en: `1. Routine:
                - Strictly follow a daily schedule.
                - Balance sleep and rest.
                
                2. Diet:
                - Vitamin-rich, balanced diet.
                - Stay hydrated.
                
                3. Stress:
                - Avoid stressful situations.
                - Psychological support is important.`,
                
                de: `1. Routine:
                - Befolgen Sie strikt einen Tagesplan.
                - Gleichgewicht von Schlaf und Ruhe.
                
                2. Ernährung:
                - Vitaminreiche, ausgewogene Ernährung.
                - Viel trinken.
                
                3. Stress:
                - Vermeiden Sie Stresssituationen.
                - Psychologische Unterstützung ist wichtig.`
            },
            medication: {
                uz: `Davolash individual ravishda belgilanadi:
                - Semptomatik terapiya (og'riq qoldiruvchilar).
                - Vitaminlar kompleksi va immunomodulyatorlar.
                - Zarurat bo'lganda maxsus preparatlar.`,
                en: `Treatment is individualized:
                - Symptomatic therapy (pain relievers).
                - Vitamin complexes and immunomodulators.
                - Specific drugs if necessary.`,
                de: `Die Behandlung ist individuell:
                - Symptomatische Therapie (Schmerzmittel).
                - Vitaminkomplexe und Immunmodulatoren.
                - Spezifische Medikamente bei Bedarf.`
            },
            prevention: {
                uz: "Muntazam tibbiy ko'rikdan o'tish va xavf omillarini kamaytirish.",
                en: "Regular medical check-ups and reducing risk factors.",
                de: "Regelmäßige ärztliche Untersuchungen und Reduzierung von Risikofaktoren."
            },
            diagnosis: {
                uz: "Qon tahlili va instrumental tekshiruvlar.",
                en: "Blood tests and instrumental examinations.",
                de: "Bluttests und instrumentelle Untersuchungen."
            },
            whenToSeeDoctor: {
                uz: "Alomatlar 3 kundan ortiq davom etsa.",
                en: "If symptoms persist for more than 3 days.",
                de: "Wenn die Symptome länger als 3 Tage anhalten."
            }
        });
    }
    
    return generated.sort((a, b) => a.title.en.localeCompare(b.title.en));
}

export const illnesses: Illness[] = [...baseIllnesses, ...generateIllnesses(750)];
