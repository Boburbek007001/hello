import { Link } from "wouter";
import { LanguageSwitcher } from "@/components/ui/LanguageSwitcher";
import { translations, Language } from "@/lib/data";
import { useState, useEffect } from "react";
import logoImage from "@assets/generated_images/minimalist_medical_cross_logo_in_soft_green_and_blue.png";

export function Layout({ children }: { children: React.ReactNode }) {
  // Initialize language state
  const [lang, setLang] = useState<Language>('uz');

  // Share language state with children via context (simplified for this prototype by cloning)
  // In a real app, use Context API. Here we'll just pass it down if possible or rely on a global store/localstorage
  // For this rapid prototype, we'll use a simple event-based approach or local storage to persist
  
  useEffect(() => {
    const savedLang = localStorage.getItem('niobilim-lang') as Language;
    if (savedLang) setLang(savedLang);
  }, []);

  const handleSetLang = (newLang: Language) => {
    setLang(newLang);
    localStorage.setItem('niobilim-lang', newLang);
    // Trigger a custom event so pages can update if they aren't direct children receiving props
    window.dispatchEvent(new CustomEvent('lang-change', { detail: newLang }));
  };

  return (
    <div className="min-h-screen flex flex-col bg-background font-sans selection:bg-primary/20 selection:text-primary">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-3 hover:opacity-90 transition-opacity group">
              <img src={logoImage} alt="Niobilim Logo" className="h-8 w-8 object-contain group-hover:scale-110 transition-transform duration-300" />
              <span className="font-serif font-bold text-xl tracking-tight text-foreground">
                Niobilim
              </span>
            </a>
          </Link>

          <div className="flex items-center gap-4">
            <LanguageSwitcher currentLang={lang} setLang={handleSetLang} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 bg-secondary/30 mt-20">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <img src={logoImage} alt="Logo" className="h-6 w-6 opacity-80" />
                <span className="font-serif font-bold text-lg">Niobilim</span>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
                {translations[lang].heroSubtitle}
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">{translations[lang].related}</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="hover:text-primary cursor-pointer transition-colors">Cardiology</li>
                <li className="hover:text-primary cursor-pointer transition-colors">Neurology</li>
                <li className="hover:text-primary cursor-pointer transition-colors">Pediatrics</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <p className="text-sm text-muted-foreground">info@niobilim.com</p>
              <div className="flex gap-4 mt-4">
                {/* Social icons placeholders */}
                <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center hover:bg-primary hover:text-white transition-colors cursor-pointer">
                   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
                </div>
                <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center hover:bg-primary hover:text-white transition-colors cursor-pointer">
                   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-border/40 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs text-muted-foreground text-center md:text-left">
              {translations[lang].footerText}
            </p>
            <p className="text-[10px] text-muted-foreground/60 max-w-md text-center md:text-right">
              {translations[lang].disclaimer}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
