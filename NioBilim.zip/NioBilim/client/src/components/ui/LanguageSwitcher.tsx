import { Language } from "@/lib/data";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface LanguageSwitcherProps {
  currentLang: Language;
  setLang: (lang: Language) => void;
}

export function LanguageSwitcher({ currentLang, setLang }: LanguageSwitcherProps) {
  const languages: { code: Language; label: string; flag: string }[] = [
    { code: 'uz', label: 'O\'zbek', flag: '🇺🇿' },
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  ];

  return (
    <div className="flex items-center gap-1 bg-secondary/50 p-1 rounded-lg border border-border/50">
      {languages.map((lang) => (
        <button
          key={lang.code}
          onClick={() => setLang(lang.code)}
          className={cn(
            "relative px-3 py-1.5 text-sm font-medium rounded-md transition-all duration-300 outline-none focus-visible:ring-2 focus-visible:ring-ring",
            currentLang === lang.code 
              ? "text-primary-foreground shadow-sm" 
              : "text-muted-foreground hover:text-foreground hover:bg-background/50"
          )}
        >
          {currentLang === lang.code && (
            <motion.div
              layoutId="active-lang"
              className="absolute inset-0 bg-primary rounded-md z-0"
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
            />
          )}
          <span className="relative z-10 flex items-center gap-1.5">
            <span className="text-xs">{lang.flag}</span>
            <span className="hidden sm:inline">{lang.label}</span>
            <span className="sm:hidden uppercase">{lang.code}</span>
          </span>
        </button>
      ))}
    </div>
  );
}
