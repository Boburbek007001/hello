import { Link } from "wouter";
import { Illness, translations, Language } from "@/lib/data";
import { motion } from "framer-motion";

interface IllnessCardProps {
  illness: Illness;
  lang: Language;
}

export function IllnessCard({ illness, lang }: IllnessCardProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="group bg-card rounded-xl p-6 border border-border/50 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-300 flex flex-col h-full"
    >
      <div className="mb-4">
        <span className="inline-block px-2.5 py-0.5 rounded-md bg-secondary text-secondary-foreground text-xs font-semibold mb-3 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
          {illness.category[lang]}
        </span>
        <Link href={`/illness/${illness.id}`}>
          <a className="block">
            <h3 className="font-serif text-xl font-bold text-foreground group-hover:text-primary transition-colors leading-tight mb-2">
              {illness.title[lang]}
            </h3>
          </a>
        </Link>
      </div>
      
      <p className="text-muted-foreground text-sm mb-6 flex-grow line-clamp-3 leading-relaxed">
        {illness.summary[lang]}
      </p>
      
      <Link href={`/illness/${illness.id}`}>
        <button className="w-full mt-auto py-2 px-4 bg-secondary/50 text-foreground rounded-lg text-sm font-medium hover:bg-primary hover:text-primary-foreground transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 group-hover:translate-x-1">
          {translations[lang].readMore}
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </button>
      </Link>
    </motion.div>
  );
}
