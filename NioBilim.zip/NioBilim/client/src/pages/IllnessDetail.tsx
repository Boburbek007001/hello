import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { illnesses, translations, Language } from "@/lib/data";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export default function IllnessDetail() {
  const [match, params] = useRoute("/illness/:id");
  const [lang, setLang] = useState<Language>('uz');
  const [showAdvice, setShowAdvice] = useState(false);

  useEffect(() => {
    const updateLang = () => {
      const saved = localStorage.getItem('niobilim-lang') as Language;
      if (saved) setLang(saved);
    };
    updateLang();
    window.addEventListener('lang-change', updateLang);
    return () => window.removeEventListener('lang-change', updateLang);
  }, []);

  if (!match || !params) return <div>404</div>;

  const illness = illnesses.find(i => i.id === params.id);

  if (!illness) return <div className="p-20 text-center">Not Found</div>;

  return (
    <Layout>
      <article className="min-h-[80vh] bg-background pb-20 pt-10">
        {/* Breadcrumbs & Header (No Hero Image) */}
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="mb-8">
             <Link href="/">
                <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-6 transition-colors text-sm font-medium">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                  {translations[lang].backToHome}
                </a>
              </Link>
          </div>
          
          <div className="border-b border-border/40 pb-8 mb-12">
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
            >
                <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-bold mb-4">
                  {illness.category[lang]}
                </span>
                <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground tracking-tight max-w-4xl leading-tight">
                  {illness.title[lang]}
                </h1>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Sidebar Navigation (Desktop) */}
            <div className="hidden lg:block lg:col-span-3 space-y-2 sticky top-24 h-fit">
               <div className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-4">Mundarija</div>
               <a href="#overview" className="block px-4 py-2 rounded-lg bg-secondary/50 text-foreground font-medium hover:bg-secondary transition-colors">Umumiy ma'lumot</a>
               <a href="#symptoms" className="block px-4 py-2 rounded-lg text-muted-foreground hover:bg-secondary/50 transition-colors">{translations[lang].symptoms}</a>
               <a href="#advice" className="block px-4 py-2 rounded-lg text-muted-foreground hover:bg-secondary/50 transition-colors">{translations[lang].advice}</a>
               <a href="#prevention" className="block px-4 py-2 rounded-lg text-muted-foreground hover:bg-secondary/50 transition-colors">{translations[lang].prevention}</a>
               <a href="#diagnosis" className="block px-4 py-2 rounded-lg text-muted-foreground hover:bg-secondary/50 transition-colors">{translations[lang].diagnosis}</a>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-9 space-y-12">
              <section id="overview">
                <h2 className="sr-only">Overview</h2>
                <p className="text-xl leading-loose text-muted-foreground font-serif first-letter:text-5xl first-letter:font-bold first-letter:mr-3 first-letter:float-left first-letter:text-primary">
                  {illness.description[lang]}
                </p>
              </section>

              <section id="symptoms" className="bg-card rounded-2xl p-8 border border-border/50 shadow-sm">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 text-primary border-b border-border/30 pb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
                  {translations[lang].symptoms}
                </h2>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-8">
                  {illness.symptoms[lang].map((symptom, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-foreground/80 leading-normal">
                      <div className="w-1.5 h-1.5 rounded-full bg-destructive/60 mt-2 flex-shrink-0" />
                      <span className="text-lg">{symptom}</span>
                    </li>
                  ))}
                </ul>
              </section>

              {/* Advice Interaction Section */}
              <section id="advice" className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/5 to-blue-500/5 border border-primary/10 p-1">
                 {!showAdvice ? (
                   <div className="p-12 text-center flex flex-col items-center justify-center min-h-[300px] bg-card/50 backdrop-blur-sm">
                     <div className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-8 ring-8 ring-primary/5">
                       <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                     </div>
                     <h3 className="text-3xl font-bold mb-4 font-serif">{translations[lang].advice}</h3>
                     <p className="text-muted-foreground mb-10 max-w-lg text-lg leading-relaxed">
                       Ushbu kasallik bo'yicha <strong>kengaytirilgan professional maslahatlar</strong>, davolash rejasi va oldini olish choralari bilan tanishish uchun quyidagi tugmani bosing.
                     </p>
                     <button 
                       onClick={() => setShowAdvice(true)}
                       className="px-10 py-5 bg-primary text-white rounded-2xl font-bold text-lg shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-3 cursor-pointer group"
                     >
                       {translations[lang].enterAdvice}
                       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:translate-x-1 transition-transform"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                     </button>
                   </div>
                 ) : (
                   <motion.div 
                     initial={{ opacity: 0, scale: 0.98 }}
                     animate={{ opacity: 1, scale: 1 }}
                     className="p-8 md:p-12 bg-white/90 backdrop-blur-md h-full"
                   >
                     <div className="flex justify-between items-start mb-10 border-b border-border/30 pb-6">
                       <h3 className="text-3xl font-bold text-primary flex items-center gap-3 font-serif">
                         <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
                         Tibbiy Tavsiyalar
                       </h3>
                       <button 
                         onClick={() => setShowAdvice(false)}
                         className="text-muted-foreground hover:text-foreground p-2 hover:bg-secondary rounded-full transition-colors"
                       >
                         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 18 12"/></svg>
                       </button>
                     </div>

                     <div className="space-y-12">
                       {/* Advice - Expanded */}
                       <div className="bg-secondary/30 p-8 rounded-2xl border-l-4 border-primary relative">
                         <div className="absolute top-8 right-8 opacity-5 text-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 21a8 8 0 0 1 13.292-6"/><circle cx="10" cy="8" r="5"/><path d="m19 16 3 3"/><path d="m19 19 3-3"/></svg>
                         </div>
                         <h4 className="font-bold mb-6 text-2xl text-primary">{translations[lang].advice}</h4>
                         <div className="text-foreground/90 text-lg leading-loose whitespace-pre-line space-y-4">
                           {illness.advice[lang]}
                         </div>
                       </div>

                       {/* Medications */}
                       <div className="bg-red-50 dark:bg-red-900/5 p-8 rounded-2xl border-l-4 border-red-400">
                         <h4 className="font-bold mb-6 text-2xl text-red-600 dark:text-red-400 flex items-center gap-2">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>
                           {translations[lang].medication}
                         </h4>
                         <div className="text-foreground/90 text-lg leading-loose whitespace-pre-line">
                           {illness.medication[lang]}
                         </div>
                       </div>

                        {/* Prevention - ID for anchor */}
                        <div id="prevention" className="bg-green-50 dark:bg-green-900/5 p-8 rounded-2xl border-l-4 border-green-500">
                         <h4 className="font-bold mb-6 text-2xl text-green-700 dark:text-green-400 flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                           {translations[lang].prevention}
                         </h4>
                         <div className="text-foreground/90 text-lg leading-loose whitespace-pre-line">
                           {illness.prevention[lang]}
                         </div>
                       </div>

                        {/* Diagnosis - ID for anchor */}
                        <div id="diagnosis" className="bg-blue-50 dark:bg-blue-900/5 p-8 rounded-2xl border-l-4 border-blue-500">
                         <h4 className="font-bold mb-6 text-2xl text-blue-700 dark:text-blue-400 flex items-center gap-2">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
                           {translations[lang].diagnosis}
                         </h4>
                         <div className="text-foreground/90 text-lg leading-loose whitespace-pre-line">
                           {illness.diagnosis[lang]}
                         </div>
                       </div>

                       {/* When to see doctor */}
                       <div className="bg-orange-50 dark:bg-orange-900/5 p-8 rounded-2xl border-l-4 border-orange-500">
                         <h4 className="font-bold mb-6 text-2xl text-orange-700 dark:text-orange-400 flex items-center gap-2">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                           {translations[lang].whenToSeeDoctor}
                         </h4>
                         <div className="text-foreground/90 text-lg leading-loose whitespace-pre-line">
                           {illness.whenToSeeDoctor[lang]}
                         </div>
                       </div>

                     </div>
                   </motion.div>
                 )}
              </section>
            </div>

          </div>
        </div>
      </article>
    </Layout>
  );
}
