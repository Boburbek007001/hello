import { useState, useEffect, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { IllnessCard } from "@/components/ui/IllnessCard";
import { illnesses, translations, Language } from "@/lib/data";
import { motion } from "framer-motion";
import heroBg from "@assets/generated_images/calming_abstract_medical_background_with_soft_teal_and_blue_gradients.png";
import { cn } from "@/lib/utils";

export default function Home() {
  const [lang, setLang] = useState<Language>('uz');
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [visibleCount, setVisibleCount] = useState(12);

  useEffect(() => {
    const updateLang = () => {
      const saved = localStorage.getItem('niobilim-lang') as Language;
      if (saved) setLang(saved);
    };
    updateLang();
    window.addEventListener('lang-change', updateLang);
    return () => window.removeEventListener('lang-change', updateLang);
  }, []);

  const alphabet = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  const filteredIllnesses = useMemo(() => {
    let result = illnesses;

    if (searchQuery) {
      result = result.filter(item => 
        item.title[lang].toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.summary[lang].toLowerCase().includes(searchQuery.toLowerCase())
      );
    } else if (selectedLetter) {
      if (selectedLetter === '#') {
         // numbers or others
         result = result.filter(item => !/^[A-Z]/.test(item.title[lang].charAt(0).toUpperCase()));
      } else {
         result = result.filter(item => item.title[lang].trim().toUpperCase().startsWith(selectedLetter));
      }
    }

    // Alphabetical sort based on current language title
    return result.sort((a, b) => a.title[lang].localeCompare(b.title[lang]));
  }, [searchQuery, selectedLetter, lang]);

  const visibleIllnesses = filteredIllnesses.slice(0, visibleCount);

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 12);
  };

  const handleLetterClick = (letter: string) => {
    setSelectedLetter(selectedLetter === letter ? null : letter);
    setVisibleCount(12);
    setSearchQuery(""); // Clear search when filtering by letter
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative w-full py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={heroBg} alt="Background" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/50 to-background" />
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6 tracking-tight">
              {translations[lang].heroTitle}
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              {translations[lang].heroSubtitle}
            </p>
            
            {/* Search Bar */}
            <div className="relative max-w-xl mx-auto mb-12">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-muted-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              </div>
              <input 
                type="text" 
                placeholder={translations[lang].searchPlaceholder}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setSelectedLetter(null); // Clear letter filter on search
                  setVisibleCount(12);
                }}
                className="w-full pl-12 pr-4 py-4 rounded-2xl border border-border/50 bg-white/80 backdrop-blur-xl shadow-lg text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all text-lg"
              />
            </div>

            {/* A-Z Filter */}
            <div className="hidden md:flex flex-wrap justify-center gap-1 bg-white/50 backdrop-blur-sm p-2 rounded-xl border border-border/30 shadow-sm max-w-3xl mx-auto">
               {alphabet.map((letter) => (
                 <button
                   key={letter}
                   onClick={() => handleLetterClick(letter)}
                   className={cn(
                     "w-8 h-8 flex items-center justify-center rounded-lg text-sm font-bold transition-all duration-200",
                     selectedLetter === letter 
                       ? "bg-primary text-primary-foreground scale-110 shadow-md" 
                       : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                   )}
                 >
                   {letter}
                 </button>
               ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Grid Section */}
      <section className="py-16 bg-background min-h-[500px]">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-8 border-b border-border/40 pb-4">
             <h2 className="text-2xl font-bold font-serif">
               {selectedLetter ? `${translations[lang].filterByLetter}: ${selectedLetter}` : translations[lang].allTopics}
               <span className="ml-2 text-sm text-muted-foreground font-sans font-normal">({filteredIllnesses.length})</span>
             </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {visibleIllnesses.map((illness) => (
              <IllnessCard key={illness.id} illness={illness} lang={lang} />
            ))}
          </div>
          
          {filteredIllnesses.length === 0 && (
            <div className="text-center py-20 text-muted-foreground">
              <p className="text-xl">No results found.</p>
            </div>
          )}

          {/* Load More */}
          {visibleCount < filteredIllnesses.length && (
            <div className="mt-12 text-center">
              <button 
                onClick={handleLoadMore}
                className="px-8 py-3 bg-secondary text-secondary-foreground rounded-full font-medium hover:bg-primary hover:text-primary-foreground transition-all shadow-sm hover:shadow-md active:scale-95"
              >
                {translations[lang].readMore} ({filteredIllnesses.length - visibleCount} more)
              </button>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}
